import httpx
import textwrap
from app.config import OLLAMA_URL, MODEL_NAME

class AIService:

    async def generate_sql(self, schema: str, user_query: str):

        system_prompt =textwrap.dedent("""
                        You are an expert MySQL SQL generator.

                        Rules:

                        1. Use ONLY the schema provided.

                        2. Never invent tables.

                        3. Never invent columns.

                        4. Return ONLY executable MySQL.

                        5. Never return markdown.

                        6. Never explain.

                        7. Always wrap column and table names in backticks (`) to avoid reserved word conflicts.

                        8. If the schema is insufficient,
                        return exactly:

                        INSUFFICIENT_SCHEMA

                        followed by a brief explanation.

                        9. Never guess.

                        10. If the question implies an order, ranking, or extremes in any way,
                            infer the user's intended sort direction and column from context,
                            and apply the appropriate ORDER BY (and LIMIT, if a specific count
                            is implied) using only columns that exist in the schema. Never
                            invent a column for this purpose — if none plausibly fits, treat
                            it as INSUFFICIENT_SCHEMA per rule 8.

                        11. Even if the question does not explicitly ask for an order, default to
                            ORDER BY the primary entity/grouping column being listed (e.g. the
                            left-hand column in "show X and their Y") so that rows belonging to
                            the same entity appear together and results are stably readable,
                            unless the question's intent is clearly satisfied without ordering
                            (e.g. a single aggregate value).
                        """)

        prompt = f"""
                Database Schema

                {schema}

                User Question

                {user_query}
                """

        payload = {
            "model": MODEL_NAME,
            "messages": [
                {
                    "role": "system",
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "stream": False,
            "think": False,
            "options": {
                "temperature": 0,
                "num_ctx": 4096,
                "num_predict": 200
            }
        }

        try:
             async with httpx.AsyncClient(timeout=120) as client:
                response = await client.post(OLLAMA_URL, json=payload)
                response.raise_for_status()
                return response.json()["message"]["content"].strip()

        except httpx.HTTPError:
            raise RuntimeError(
                "Cannot connect to Ollama. Make sure 'ollama serve' is running."
            )

        except Exception as e:
            raise RuntimeError(f"AI generation failed: {e}")
    async def generate_file_sql(self, schema: str, user_query: str):

        system_prompt = textwrap.dedent("""
                        You are an expert SQLite query generator for uploaded spreadsheet data.

                        Rules:

                        1. Use ONLY the table named `uploaded_data`.

                        2. Use ONLY the columns provided in the schema.

                        3. Return ONLY executable SQLite SELECT SQL.

                        4. Never return markdown.

                        5. Never explain.

                        6. Always wrap table and column names in backticks (`).

                        7. Do not modify data. Never use INSERT, UPDATE, DELETE, DROP, ALTER, CREATE, PRAGMA, or ATTACH.

                        8. If the question cannot be answered from the uploaded file, return exactly:

                        INSUFFICIENT_SCHEMA

                        followed by a brief explanation.

                        9. If the question implies an order, ranking, or extremes in any way,
                        infer the user's intended sort direction and column from context,
                        and apply the appropriate ORDER BY (and LIMIT, if a specific count
                        is implied) using only columns that exist in the uploaded_data
                        table's schema. Never invent a column for this purpose — if none
                        plausibly fits, treat it as INSUFFICIENT_SCHEMA per rule 8.

                        10. Even if the question does not explicitly ask for an order, default to
                        ORDER BY the primary entity/grouping column being listed (e.g. the
                        left-hand column in "show X and their Y") so that rows belonging to
                        the same entity appear together and results are stably readable,
                        unless the question's intent is clearly satisfied without ordering
                        (e.g. a single aggregate value).
                        """)

        prompt = f"""
                Uploaded File Schema

                {schema}

                User Question

                {user_query}
                """

        payload = {
            "model": MODEL_NAME,
            "messages": [
                {
                    "role": "system",
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "stream": False,
            "think": False,
            "options": {
                "temperature": 0,
                "num_ctx": 4096
            }
        }

        try:
             async with httpx.AsyncClient(timeout=120) as client:
                response = await client.post(OLLAMA_URL, json=payload)
                response.raise_for_status()
                return response.json()["message"]["content"].strip()

        except httpx.HTTPError:
            raise RuntimeError(
                "Cannot connect to Ollama. Make sure 'ollama serve' is running."
            )

        except Exception as e:
            raise RuntimeError(f"AI generation failed: {e}")

